> [!info] **Compilação pessoal de informações**
> - **Temática**: Disciplina de ecologia de populações por Peter Zuidema
> - **Tags:** #Demografia #Demografia/MPM #Demografia/IPM #Projetos/ITV/Carajasia #Projetos/ITV/Daphonpsis #Projetos/ITV/Ipomoea 


- Dados a serem utilizados durante a disciplina.
- Aqui estão os dados já formatados para a disciplina. Limpos



# Carajasia

```{R "Carregando dados Carajasia"}
library(readr)
dados_carajasia <- read_csv("Carajasia_zuidema2025.csv")
```

